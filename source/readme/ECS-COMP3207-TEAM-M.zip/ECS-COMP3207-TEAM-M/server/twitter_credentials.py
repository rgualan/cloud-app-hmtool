# twitter_credentials.py
# Twitter credential
# Required for tweet collection
consumer_key = "RdCtxLXLNfBn06Q5JKAFoe2z5"
consumer_secret = "A2wJuUQq2rbgDsFWUwln52K2sL70uOrswMolLLeHc05snPiOsy"
access_token = ""
access_token_secret = ""
